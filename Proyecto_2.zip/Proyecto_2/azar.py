#!/usr/bin/env python
# -*- coding: utf-8 -*-

from random import random


def tamano(dimencion, minimo):
    num = int(random()*dimencion + 1)
    while num < minimo:
        num = int(random()*dimencion + 1)
    return num


def posicion_aleatorio(laberinto):
    num = int(random() * len(laberinto))
    if num == 0:
        num = num + 3
    elif num == len(laberinto) - 1:
        num = num - 3
    return num