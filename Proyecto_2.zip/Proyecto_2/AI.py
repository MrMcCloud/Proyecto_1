#!/usr/bin/env python
# -*- coding: utf-8 -*-

from memoria import cargado_memoria, creacion_aprendizaje
from collections import deque


def template(maze):
    height = len(maze)
    width = len(maze[0]) if height else 0
    graph = {(i, j): [] for j in range(width) for i in range(height) if not maze[i][j]}
    for row, col in graph.keys():
        if row < height - 1 and not maze[row + 1][col]:
            graph[(row, col)].append(("S", (row + 1, col)))
            graph[(row + 1, col)].append(("N", (row, col)))
        if col < width - 1 and not maze[row][col + 1]:
            graph[(row, col)].append(("E", (row, col + 1)))
            graph[(row, col + 1)].append(("W", (row, col)))
    return graph


def bfs(maze):
    start, goal = (1, 1), (len(maze) - 2, len(maze[0]) - 2)
    queue = deque([("", start)])
    visited = set()
    graph = template(maze)
    usuario = False
    while queue:
        path, current = queue.popleft()
        if current == goal:
            return path
        if current in visited:
            continue
        visited.add(current)
        for direction, neighbour in graph[current]:
            queue.append((path + direction, neighbour))
    creacion_aprendizaje(usuario, queue, len(maze))
    return queue


def traductor(id):
    data = cargado_memoria()
    camino = []
    salidas = []
    id = str(id) + 'x' + str(id)
    for tablero in data['memoria']:
        if id in tablero:
            for j in range(len(tablero[id])):
                camino.append(tablero[id][j])
            salidas.append(camino)
    print(salidas)
    return salidas


def coincidencia(laberinto, final):
    salidas = traductor(len(laberinto))
    posibles_salidas = []
    for i in range(len(salidas)):
        considencia = 0
        for j in range(len(salidas[i])):
            punto = salidas[i][j]
            y = punto[0]
            x = punto[1]
            if laberinto[y][x] != '*':
                considencia = considencia + 1
            if considencia >= len(laberinto) - 1:
                if punto[0] == final[0]:
                    if punto[1] == final[1]:
                        posibles_salidas.append(salidas[i])
    return posibles_salidas


def mayor_menor(lista):
    for i in range(len(lista)):
        for j in range(len(lista)):
            if lista[i] < lista[j]:
                temp = lista[j]
                lista[j] = lista[i]
                lista[i] = temp
                lista.append(lista[j])
    return lista


def menor_mayor(lista):
    for i in range(len(lista)):
        for j in range(len(lista)):
            if lista[i] > lista[j]:
                temp = lista[j]
                lista[j] = lista[i]
                lista[i] = temp
                lista.append(lista[j])
    return lista


def comparacion_caminos(salidas, decision):
    tamanio = []
    for i in range(len(salidas)):
        tamanio.append(len(salidas[i]))
    print(tamanio)
    if decision == "1":
        print("el camino mas largo es:")
        tamanio = mayor_menor(tamanio)
        for i in range(len(salidas)):
            if tamanio[0] == len(salidas[i]):
                return salidas[i]
    if decision == "2":
        print("el camino mas corto es:")
        tamanio = menor_mayor(tamanio)
        for i in range(len(salidas)):
            if tamanio[0] == len(salidas[i]):
                return salidas[i]
    if decision == "3":
        print("el camino mediano es:")
        mayor = mayor_menor(tamanio)
        menor = menor_mayor(tamanio)
        for i in range(len(tamanio)):
            if mayor[i] == menor[i]:
                if mayor[i] == len(salidas[i]):
                    return salidas[i]
