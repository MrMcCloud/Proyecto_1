#!/usr/bin/env python
# -*- coding: utf-8 -*-

from random import random
from azar import tamano, posicion_aleatorio


def generacion_laberinto(max, min):
    num = tamano(max, min)
    laberinto = []
    for i in range(num):
        laberinto.append(["*"]*num)
    return laberinto


def vector(largo_max,largo_min, tope):
    punto = []
    direccion = int(random() * 4 + 1)
    direccion = bloqueo_direccion(direccion, tope)
    magnitud = int(random() * largo_max + 1)
    while magnitud < largo_min:
        magnitud = int(random() * largo_max + 1)
    punto.append(direccion)
    punto.append(magnitud)
    return punto


def bloqueo_direccion(direccion, tope):
    if tope[0] == 1:
        while direccion == 1:
            direccion = int(random() * 4 + 1)
    elif tope[1] == 1:
        while direccion == 2:
            direccion = int(random() * 4 + 1)
    elif tope[2] == 1:
        while direccion == 3:
            direccion = int(random() * 4 + 1)
    elif tope[3] == 1:
        while direccion == 4:
            direccion = int(random() * 4 + 1)
    return direccion


def bloqueo(direccion, tope):
    if direccion == 1:
        tope[0] = 1
        tope[2] = 0
        tope[3] = 0
    elif direccion == 2:
        tope[1] = 1
        tope[2] = 0
        tope[3] = 0
    elif direccion == 3:
        tope[0] = 0
        tope[1] = 0
        tope[2] = 1
    elif direccion == 4:
        tope[0] = 0
        tope[1] = 0
        tope[3] = 1
    return tope


def paso(prueba, posicion, min, max, validador):
    y = posicion[0]
    x = posicion[1]
    temp = []
    if prueba == validador[0]:
        if y > min:
            y = y - 1
        elif y == min:
            y = y + 1
    elif prueba == validador[1]:
        if y < max:
            y = y + 1
        elif y == max:
            y = y - 1
    elif prueba == validador[2]:
        if x > min:
            x = x - 1
        elif x == min:
            x = x + 1
    elif prueba == validador[3]:
        if x < max - 1:
            x = x + 1
        elif x == max - 1:
            x = x - 1
    temp.append(y)
    temp.append(x)
    return temp


def caminar(laberinto, sentido, posicion, tope, sinsalida):
    direccion = sentido[0]
    magnitud = sentido[1]
    movimiento = posicion
    validador = [1, 2, 3, 4]
    temp = []
    punto = []
    y = 0
    x = 0
    salida = False
    max = len(laberinto)
    min = 1
    for i in range(magnitud):
        movimiento = paso(direccion, movimiento, min, max, validador)
        y = movimiento[0]
        x = movimiento[1]
        if direccion == 1 or direccion == 2:
            if y > 1:
                if y < len(laberinto):
                    if laberinto[y][x] == '*':
                        laberinto[y][x] = ' '
                    elif laberinto[y][x] != '*':
                        break
                if sinsalida is False:
                    if y == len(laberinto) - 1:
                        laberinto[y][x] = ' '
                        salida = True
                        break
                elif sinsalida is True:
                    if y == len(laberinto) - 2:
                        laberinto[y][x] = ' '
                        salida = True
                        break
            else:
                break
        elif direccion == 3 or direccion == 4:
            if x > 1:
                if x < len(laberinto) - 1:
                    if laberinto[y][x] == '*':
                        laberinto[y][x] = ' '
                    elif laberinto[y][x] != '*':
                        break
                elif x == len(laberinto) - 1:
                    x = x - 1
                    break
            else:
                break
    tope = bloqueo(direccion, tope)
    punto.append(y)
    punto.append(x)
    temp.append(laberinto)
    temp.append(punto)
    temp.append(tope)
    temp.append(salida)
    return temp


def ruta(laberinto, largo, xy, sinsalida):
    largo_max = largo[0]
    largo_min = largo[1]
    x = xy[1]
    y = xy[0]
    laberinto[y][x] = ' '
    posicion = [y, x]
    tope = [0, 0, 0, 0]
    final = False
    while final is False:
        sentido = vector(largo_max, largo_min, tope)
        temp = caminar(laberinto, sentido, posicion, tope, sinsalida)
        laberinto = temp[0]
        posicion = temp[1]
        tope = temp[2]
        salida = temp[3]
        if salida is True:
            final = True
    return laberinto


def laberinto_final():
    laberinto = generacion_laberinto(50, 40)
    largo = [5, 3]
    y1 = 1
    y2 = posicion_aleatorio(laberinto) // 2
    x1 = posicion_aleatorio(laberinto)
    x2 = posicion_aleatorio(laberinto) // 2
    xy = [y1, x1]
    xy_random = [y2, x2]
    laberinto[0][x1] = 'X'
    laberinto = ruta(laberinto, largo, xy, False)
    laberinto_f = ruta(laberinto, largo, xy_random, True)
    return laberinto_f

###############################################################################
