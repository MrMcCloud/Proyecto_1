#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json

info = {}
info['memoria'] = []


def cargado_memoria():
    with open('laberinto.json', 'r') as file:
        memoria = json.load(file)
    return memoria


def guardado_memoria(memoria):
    with open('laberinto.json', 'w') as file:
        json.dump(memoria, file, indent=4, ensure_ascii=False)


def creacion_aprendizaje(usuario, rutas, id):
    memoria = {}
    id = str(id) + 'x' + str(id)
    memoria[id] = {}
    if usuario is True:
        memoria[id]['patterns'] = []
        for i in range(len(rutas)):
            nombre = 'enseñanza' + str(i)
            temp = rutas[i]
            memoria[id]['patterns'].append({nombre: temp})
        info['memoria'].append(memoria)
        guardado_memoria(info)
    elif usuario is False:
        for i in range(len(rutas)):
            patron = 'patterns' + str(i)
            memoria[id][patron] = []
            for j in range(len(rutas)):
                nombre = 'enseñanza' + str(i)
                temp = rutas[i]
                memoria[id][patron].append({nombre: temp})
            info['memoria'].append(memoria)
            guardado_memoria(info)