#!/usr/bin/env python
# -*- coding: utf-8 -*-

from memoria import creacion_aprendizaje
from AI import bfs, coincidencia, comparacion_caminos


def ruta_jugador(data):
    laberinto = data[0]
    ys = data[1]
    xs = data[2]
    for i in range(len(laberinto)):
        for j in range(len(laberinto)):
            for k in range(len(ys)):
                if laberinto[i][j] != "*":
                    if i == ys[k] and j == xs[k]:
                        laberinto[i][j] = "X"
    return data[0]


def ingresar_letra(dic, movimiento):
    validacion = False
    while validacion is False:
        for i in range(4):
            if movimiento == dic["orientacion"][i]:
                validacion = True
                break
        if validacion is False:
            print("la tecla ingresada es un numero, "
                  "una letra en mayuscula "
                  "o una letra distinta de: "
                  "w, s, a, d. \ningrese otra:")
            movimiento = str(input(">>>"))
    return movimiento


def validacion_entrada(laberinto, posicion, i, j):
    if laberinto[i][j] == 'X':
        posicion.append(i)
        posicion.append(j)
    return posicion


def entrada(laberinto, rango, decision):
    posicion = []
    largo = rango[0]
    ancho = rango[1]
    if decision is True:
        for i in range(ancho):
            posicion = validacion_entrada(laberinto, posicion, largo, i)
    elif decision is False:
        for i in range(largo):
            for j in range(ancho):
                posicion = validacion_entrada(laberinto, posicion, i, j)
    return posicion


def recorer(laberinto, prueba, posicion, min, max, validador):
    y = posicion[0]
    x = posicion[1]
    temp = []
    if prueba == validador[0]:
        if y > min:
            y = y - 1
            if laberinto[y][x] != "*":
                laberinto[y][x] = "X"
                laberinto[y + 1][x] = ' '
            elif laberinto[y][x] == "*":
                print("no se puede mover en esa direccion, "
                      "ya que hay una pared ")
                y = y + 1
    elif prueba == validador[1]:
        if y < max:
            y = y + 1
            if y == max:
                laberinto[y - 1][x] = ' '
            elif laberinto[y][x] != "*":
                laberinto[y - 1][x] = ' '
                laberinto[y][x] = "X"
            elif laberinto[y][x] == "*":
                print("no se puede mover en esa direccion, "
                      "ya que hay una pared ")
                y = y - 1
    elif prueba == validador[2]:
        if x > min:
            x = x - 1
            if laberinto[y][x] != "*":
                laberinto[y][x] = "X"
                laberinto[y][x + 1] = ' '
            elif laberinto[y][x] == "*":
                print("no se puede mover en esa direccion, "
                      "ya que hay una pared ")
                x = x + 1
    elif prueba == validador[3]:
        if x < max - 1:
            x = x + 1
            if laberinto[y][x] != "*":
                laberinto[y][x] = "X"
                laberinto[y][x - 1] = ' '
            elif laberinto[y][x] == "*":
                print("no se puede mover en esa direccion, "
                      "ya que hay una pared ")
                x = x - 1
    temp.append(y)
    temp.append(x)
    temp.append(laberinto)
    return temp


def avanzar_laberinto(laberinto):
    rango = [0, len(laberinto)]
    dic = {"orientacion": ["w", "s", "a", "d"]}
    posicion = entrada(laberinto, rango, True)
    posiciones_y = []
    posiciones_x = []
    ruta = []
    data = []
    paquete = []
    max = len(laberinto)
    min = 0
    print("para salir del laberinto utilice las teclas: w(arriba), "
          "s(abajo), a(izquierda) y d(derecha) para moverse")
    final = False
    while final is False:
        ruta.append(posicion)
        imprimir_laberinto(laberinto)
        print("¿de que forma desea jugar?:\n"
              "manual(ingrese w, s, a o d)\n"
              "automatica(ingresar 1)")
        decision = str(input(">>>"))
        decision = validacion_decision(decision, 2)
        if decision != "1":
            usuario = True
            temp = recorer(laberinto, decision, posicion,
                           min, max, dic["orientacion"])
            posicion = [temp[0], temp[1]]
            posiciones_y.append(temp[0])
            posiciones_x.append(temp[1])
            if temp[0] == len(laberinto):
                data.append(laberinto)
                data.append(posiciones_y)
                data.append(posiciones_x)
                creacion_aprendizaje(usuario, ruta, max)
                final = True
        elif decision == "1":
            posiciones_y = []
            posiciones_x = []
            rango = [0, len(laberinto)]
            final = entrada(laberinto, rango, False)
            salidas = coincidencia(laberinto, final)
            if len(salidas) < 3:
                salidas = bfs(laberinto)
                print(salidas)
            print("¿que deceas hacer?:\n"
                  "ver el camino mas largo(ingrese 1)\n"
                  "ver el camino mas corto(ingresar 2)\n "
                  "ver el camino medio(ingresar 3)")
            eleccion = str(input(">>>"))
            eleccion = validacion_decision(eleccion, 3)
            camino = comparacion_caminos(salidas, eleccion)
            print(camino)
            for i in range(len(camino)):
                punto = camino[i]
                y = punto[0]
                x = punto[1]
                posiciones_y.append(y)
                posiciones_x.append(x)
            data.append(laberinto)
            data.append(posiciones_y)
            data.append(posiciones_x)
            final = True
        paquete.append(data)
        paquete.append("2")
    return paquete


def imprimir_laberinto(laberinto):
    for i in range(len(laberinto)):
        for j in range(len(laberinto[i])):
            print(laberinto[i][j], end=' ')
        print("")
    print("")


def validacion_decision(decision, menu):
    validacion = False
    while validacion is False:
        if decision == "1":
            validacion = True
        elif decision == "2":
            validacion = True
        elif menu == 1:
            if decision == "3":
                validacion = True
            else:
                print("esa no es una decision valida")
                print("¿que deseas hacer?:\n"
                      "jugar de nuevo(ingrese 1)\n "
                      "ver el camino recorido(ingrese 2)\n "
                      "cerrar programa(ingrese 3)")
                decision = str(input(">>>"))
        elif menu == 2:
            dic = {"orientacion": ["w", "s", "a", "d"]}
            if decision in dic["orientacion"]:
                validacion = True
            elif decision not in dic["orientacion"]:
                print("esa no es una decision valida")
                print("¿de que forma desea jugar?:\n"
                      "manual(ingrese w, s, a o d)\n"
                      "automatica(ingresar 1)")
                decision = str(input(">>>"))
        elif menu == 3:
            if decision == "3":
                validacion = True
            else:
                print("esa no es una decision valida")
                print("¿que deceas hacer?:\n"
                      "ver el camino mas largo(ingrese 1)\n"
                      "ver el camino mas corto(ingresar 2)\n "
                      "ver el camino medio(ingresar 3)")
                decision = str(input(">>>"))
    return decision