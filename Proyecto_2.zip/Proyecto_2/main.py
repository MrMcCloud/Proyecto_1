#!/usr/bin/env python
# -*- coding: utf-8 -*-

from manipulacion import avanzar_laberinto, imprimir_laberinto
from manipulacion import ruta_jugador, validacion_decision
from orden import laberinto_final


jugador = []
automatico = []
decision = "1"
final = False
while final is False:
    if decision == "1":
        print("bienvenido al laberinto del minotauro")
        laberinto = laberinto_final()
        info = avanzar_laberinto(laberinto)
        jugador = info[0]
        automatico = info[1]
        final = False
    elif decision == "2":
        if automatico != "2":
            print("este es el camino que recorriste ")
        imprimir_laberinto(ruta_jugador(jugador))
        final = False
    elif decision == "3":
        final = True
    if final is False:
        print("¿que deseas hacer?\njugar de nuevo(ingrese 1)"
              "\nver el camino recorido(ingrese 2)")
        print("cerrar programa(ingrese 3)")
        decision = str(input(">>>"))
        decision = validacion_decision(decision, 1)